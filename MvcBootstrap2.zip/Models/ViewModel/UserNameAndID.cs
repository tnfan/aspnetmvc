﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcBootstrap.Models.ViewModel
{
    public class UserNameAndID
    {
        public long ID { get; set; }
        public string UserName { get; set; }
    }
}